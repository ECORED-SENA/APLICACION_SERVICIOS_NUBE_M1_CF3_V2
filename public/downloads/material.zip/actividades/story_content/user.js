function ExecuteScript(strId)
{
  switch (strId)
  {
      case "61jZ919I73g":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

